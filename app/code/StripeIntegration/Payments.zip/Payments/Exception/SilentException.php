<?php

namespace StripeIntegration\Payments\Exception;

class SilentException extends \Magento\Framework\Exception\LocalizedException
{

}
